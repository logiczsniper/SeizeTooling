from src.main import seize


if __name__ == "__main__":
    seize()
